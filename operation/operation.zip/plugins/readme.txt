operamasks-ui 示例工程
======================
1、将operamasks-ui.war部署到符合Servlet 2.5/JSP2.1的所有Web容器或J2EE应用服务器
2、以Tomcat6.0为例，war包部署成功后访问：http://127.0.0.1:8080/operamasks-ui/